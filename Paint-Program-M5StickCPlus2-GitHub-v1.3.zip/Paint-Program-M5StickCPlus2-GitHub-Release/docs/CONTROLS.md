# 🎮 Complete Controls Guide

## 🕹️ Joystick Controls

### Movement
- **Full Analog Control**: 360° smooth movement
- **Precision**: Optimized sensitivity for detailed work
- **Dead Zone**: 150 units for stable center position
- **Speed**: Variable - gentle movements = fine control, full deflection = faster movement

### Button Functions
| Press Type | Duration | Function | Visual Feedback |
|------------|----------|----------|-----------------|
| **Quick Press** | <800ms | Cycle through colors | LED changes to new color |
| **Long Hold** | ≥800ms | Toggle draw mode | LED bright (draw) / dim (move) |

### LED Indicators
- **Bright Color**: Drawing enabled, LED shows brush color
- **Dim White**: Drawing disabled (move mode)
- **Green**: Hat connected successfully
- **Off**: Hat not connected or error

## 🔘 Button Layout

### Button A (Main Button)
- **Function**: Cycle brush size
- **Sequence**: 1 → 2 → 3 → 4 → 5 → 8 → 1...
- **Visual**: Brush preview updates immediately
- **Status Bar**: Shows "Size: X"

### Button B (Side Button)
- **Function**: Open color palette menu
- **Layout**: 4x3 grid of colors
- **Navigation**: Use joystick to select
- **Exit**: Press B again or select color

### PWR Button (Power/Side)
- **Function**: Clear canvas
- **Action**: Fills canvas with selected background color
- **Confirmation**: Immediate (no undo)
- **Preservation**: UI elements remain

## 📱 Status Indicators

### Top Status Bar
| Element | Description |
|---------|-------------|
| **"Paint"** | App name |
| **"DRAW"/"MOVE"** | Current mode (green/gray) |
| **"A:Size B:Color"** | Control hints |
| **Battery %** | Real-time battery level |

### Bottom Status Bar
| Element | Description |
|---------|-------------|
| **Brush Circle** | Current brush size preview |
| **"Size: X"** | Numeric size indicator |
| **Battery %** | Battery percentage |

## 🎨 Drawing Modes

### MOVE Mode (Default)
- **Cursor**: Blinking gray crosshair
- **Movement**: Free cursor movement
- **Drawing**: Disabled
- **LED**: Dim white
- **Purpose**: Navigate without drawing

### DRAW Mode (Hold Joy Button)
- **Cursor**: No cursor (prevents artifacts)
- **Movement**: Draws continuous lines
- **Drawing**: Enabled
- **LED**: Bright brush color
- **Purpose**: Active drawing/painting

## 🌈 Color System

### Quick Color Cycling (Joy Press)
**Sequence**: Black → White → Red → Green → Blue → Yellow → Cyan → Magenta → Orange → Purple → Pink → Gray → Black...

### Color Menu (Button B)
**Grid Layout** (4 columns × 3 rows):
```
Black   White   Red     Green
Blue    Yellow  Cyan    Magenta  
Orange  Purple  Pink    Gray
```

**Navigation**:
- **Joystick**: Move selection highlight
- **Joy Press/Button A**: Select color
- **Button B**: Exit menu

## 🖌️ Brush System

### Available Sizes
| Size | Pixels | Use Case |
|------|--------|----------|
| **1** | 1px | Fine details, outlines |
| **2** | 2px | Default, general drawing |
| **3** | 3px | Medium strokes |
| **4** | 4px | Bold lines |
| **5** | 5px | Thick strokes |
| **8** | 8px | Fill areas, backgrounds |

### Size Cycling (Button A)
- **Quick Press**: Next size in sequence
- **Visual**: Brush preview updates
- **Memory**: Size remembered between sessions

## 📐 Canvas Controls

### Drawing Area
- **Size**: 135×195 pixels (full screen minus UI)
- **Bounds**: Cursor constrained to drawable area
- **Background**: Selectable from 6 colors
- **Clearing**: PWR button fills with background

### Background Colors
1. **White** (default)
2. **Black**
3. **Light Blue**
4. **Light Orange**
5. **Cyan**
6. **Yellow**

## ⚙️ Menu Navigation

### Color Menu
- **Open**: Button B
- **Navigate**: Joystick movement
- **Select**: Joy press or Button A
- **Exit**: Button B or make selection
- **Persistence**: Canvas preserved

### Brush/Background Menu
- **Open**: Via welcome screen or future updates
- **Brush Selection**: Joystick up/down
- **Background**: Joystick left/right
- **Apply**: Joy press or Button A
- **Exit**: Button B

## 🔧 Advanced Tips

### Precision Drawing
1. **Small Movements**: Gentle joystick for fine control
2. **Size 1 Brush**: For detailed work
3. **MOVE Mode**: Navigate without drawing
4. **Color Planning**: Quick press joy for fast color changes

### Speed Techniques
1. **Hold Draw Mode**: Toggle once, draw continuously
2. **Button A**: Quick brush size changes
3. **Joy Press**: Instant color cycling
4. **Background**: Use different canvas colors

### Battery Conservation
- **Drawing Mode**: Only enable when actively drawing
- **LED Feedback**: Minimal power usage
- **Sleep Mode**: Device auto-sleeps when idle

---

**Master these controls for amazing digital art!** 🎨🚀